import { mount } from 'svelte'
import './app.css'
import App from './FurryFresh.svelte'

mount(App, {
  target: document.getElementById('app')
})